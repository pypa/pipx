#ifndef _PYGOBJECT_INTERNAL_H_
#define _PYGOBJECT_INTERNAL_H_

#define _INSIDE_PYGOBJECT_
#include "pygobject.h"

#endif /*_PYGOBJECT_INTERNAL_H_*/
