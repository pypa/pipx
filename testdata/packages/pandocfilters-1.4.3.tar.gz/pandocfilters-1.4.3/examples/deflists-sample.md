Some Definitions

Term 1

:   Definition 1

Term 2 with *inline markup*

:   Definition 2

        { some code, part of Definition 2 }

    Third paragraph of definition 2.

Term with Äüö

: Definition with Äüö


Regular Text.