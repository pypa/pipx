
Regular text with Äüö.

<!-- BEGIN COMMENT -->

This is a comment with Äüö

<!-- END COMMENT -->

This is regular text again.