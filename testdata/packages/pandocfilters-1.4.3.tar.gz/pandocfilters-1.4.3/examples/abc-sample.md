
Use this


```
X:7
T:Qui Tolis (Trio)
C:André Raison
M:3/4
L:1/4
Q:1/4=92
%%staves {(Pos1 Pos2) Trompette}
K:F
%
V:Pos1
%%MIDI program 78
"Positif"x3  |x3    |c'>ba|Pga/g/f|:g2a  |ba2    |g2c- |c2P=B  |c>de  |fga    |
V:Pos2
%%MIDI program 78
        Mf>ed|cd/c/B|PA2d |ef/e/d |:e2f  |ef2    |c>BA |GA/G/F |E>FG  |ABc-   |
V:Trompette
%%MIDI program 56
"Trompette"z3|z3    |z3   |z3     |:Mc>BA|PGA/G/F|PE>EF|PEF/E/D|C>CPB,|A,G,F,-|
```

to get

```abc
X:7
T:Qui Tolis (Trio)
C:André Raison
M:3/4
L:1/4
Q:1/4=92
%%staves {(Pos1 Pos2) Trompette}
K:F
%
V:Pos1
%%MIDI program 78
"Positif"x3  |x3    |c'>ba|Pga/g/f|:g2a  |ba2    |g2c- |c2P=B  |c>de  |fga    |
V:Pos2
%%MIDI program 78
        Mf>ed|cd/c/B|PA2d |ef/e/d |:e2f  |ef2    |c>BA |GA/G/F |E>FG  |ABc-   |
V:Trompette
%%MIDI program 56
"Trompette"z3|z3    |z3   |z3     |:Mc>BA|PGA/G/F|PE>EF|PEF/E/D|C>CPB,|A,G,F,-|
```

See [(this is a link to whatever)](#whatever) for an example with options
`{.abc #whatever caption="this is the caption" width=50%}`.

```{.abc #whatever caption="this is the caption" width=50%}
X:7
T:Qui Tolis (Trio)
C:André Raison
M:3/4
L:1/4
Q:1/4=92
%%staves {(Pos1 Pos2) Trompette}
K:F
%
V:Pos1
%%MIDI program 78
"Positif"x3  |x3    |c'>ba|Pga/g/f|:g2a  |ba2    |g2c- |c2P=B  |c>de  |fga    |
V:Pos2
%%MIDI program 78
        Mf>ed|cd/c/B|PA2d |ef/e/d |:e2f  |ef2    |c>BA |GA/G/F |E>FG  |ABc-   |
V:Trompette
%%MIDI program 56
"Trompette"z3|z3    |z3   |z3     |:Mc>BA|PGA/G/F|PE>EF|PEF/E/D|C>CPB,|A,G,F,-|
```
