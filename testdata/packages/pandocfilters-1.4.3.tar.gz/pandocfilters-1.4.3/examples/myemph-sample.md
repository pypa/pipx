\newcommand{\myemph}[1]{ START-MYEMPH #1 END-MYEMPH }


This is same text with *emphasis with Äüö*.