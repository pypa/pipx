Use this

```math
a^2 + b^2 = c^2
```

to get

$$
a^2 + b^2 = c^2
$$

also you go from $`a^2 + b^2 = c^2`$ to $a^2 + b^2 = c^2$

`inline code`

```
fenced non-math code
    block
```

    non-math code block
    by indentation
