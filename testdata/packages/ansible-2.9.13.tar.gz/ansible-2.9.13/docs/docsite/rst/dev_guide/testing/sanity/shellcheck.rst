shellcheck
==========

Static code analysis for shell scripts using the excellent `shellcheck <https://www.shellcheck.net/>`_ tool.
