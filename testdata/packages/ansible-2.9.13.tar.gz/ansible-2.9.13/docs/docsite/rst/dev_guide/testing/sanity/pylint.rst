pylint
======

Python static analysis for common programming errors.
