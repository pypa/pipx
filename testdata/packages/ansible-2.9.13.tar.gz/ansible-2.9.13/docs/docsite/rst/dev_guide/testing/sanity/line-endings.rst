line-endings
============

All files must use ``\n`` for line endings instead of ``\r\n``.
