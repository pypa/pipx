from jupyter_console import app

if __name__ == '__main__':
    app.launch_new_instance()
