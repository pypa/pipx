# This is a bundled msgpack 0.5.6 with local modifications.
# Changes:
# +borg1: drop support for old buffer protocol to be compatible with py310
#         (backport of commit 9ae43709e42092c7f6a4e990d696d9005fa1623d)
version = (0, 5, 6, '+borg1')

