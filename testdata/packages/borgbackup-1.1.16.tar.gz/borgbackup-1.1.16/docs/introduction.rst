Introduction
============

.. this shim is here to fix the structure in the PDF
   rendering. without this stub, the elements in the toctree of
   index.rst show up a level below the README file included

.. include:: ../README.rst
