.. include:: benchmark_crud.rst.inc
