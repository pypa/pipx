:orphan:

.. include:: global.rst.inc

Borg documentation
==================

.. when you add an element here, do not forget to add it to index.rst
.. Note: Some things are in appendices (see latex_appendices in conf.py)

.. toctree::
    :maxdepth: 2

    introduction
    installation
    quickstart
    usage
    deployment
    faq
    support
    resources
    changes
    internals
    development
    authors
