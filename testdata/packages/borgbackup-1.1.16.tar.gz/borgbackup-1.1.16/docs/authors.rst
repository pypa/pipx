.. include:: global.rst.inc

Authors
=======

.. include:: ../AUTHORS

License
=======

.. _license:

.. include:: ../LICENSE
   :literal:
