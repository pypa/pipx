/* extra.h - extra stuff in C */

void *misaka_get_renderer(const hoedown_renderer_data *data);
