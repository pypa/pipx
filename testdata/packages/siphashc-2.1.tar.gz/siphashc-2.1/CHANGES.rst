Changes
=======

2.1
---

* Fixed publishing wheels in pypi.org.

2.0
---

* Dropped support for Python 2.

1.3
---

* Changed license to ISC.
* Fixed depreciation warning on Python 3.8.

1.2
---

* Included tests in the pypi package.

1.1
---

* Fixed README enconding.
* Included documentation in the pypi package.

1.0
---

* Stable release.
* Documentation improvements.

0.8
---

* First release under new maintainer.
* Merged two siphashc module implementations.
