# Make sure to update package.json, too!
version_info = (5, 1, 3)
__version__ = '.'.join(map(str, version_info))
