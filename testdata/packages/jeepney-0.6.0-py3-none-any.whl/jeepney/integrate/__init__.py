"""Deprecated: use jeepney.io instead"""
